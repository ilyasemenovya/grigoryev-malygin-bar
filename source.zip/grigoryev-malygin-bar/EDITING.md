# GM.EVENT editor handoff - 2026-09-21

This archive contains the current source for the published website, including all nine service pages and the latest Roman Malygin biography.

## Editing

- components/bar-landing.tsx: homepage and team biographies
- lib/services.ts: service order and product page content
- components/site-header.tsx: header and menu
- components/contact-section.tsx: contact section
- components/product-page.tsx: product page layout
- styles/bar.css: shared responsive styles
- public/: images, video and font assets

## Build

Requires Node.js 22.13+ and pnpm.

    pnpm install --frozen-lockfile
    pnpm build

Preview the resulting demo/ directory with a local static server. The repository root is the compiled GitHub Pages site, not the working source. Extract this archive into a separate directory for development.

## Publish

Copy every file listed in demo/asset-manifest.json from demo/ into the repository root and retain .nojekyll. Commit to main to publish with GitHub Pages. Refresh source.zip alongside future source changes so other editors receive the latest version.

The older README includes background on the original demo and video assets. Its references to four formats are historical; the current site has nine service directions.
