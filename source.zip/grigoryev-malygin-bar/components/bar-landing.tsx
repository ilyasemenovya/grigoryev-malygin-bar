'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { ArrowDown, ArrowUpRight, Copy, Check, Phone, MessageCircle, Pause, Play } from 'lucide-react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';

const phone = '+79196564524';
const services = [
  {
    id: 'cocktail', number: '01', title: 'Коктейльный бар',
    description: 'От знакомой классики до сочетаний, которые подберём вместе. Составим меню, продумаем оформление и подачу, возьмём работу бара на себя.',
    details: ['Коктейльное меню', 'Оформление', 'Барная команда'],
    message: 'Здравствуйте! Хотим обсудить выездной коктейльный бар.',
  },
  {
    id: 'bartender', number: '02', title: 'Бармен на час',
    description: 'Для домашней вечеринки или площадки, где уже есть бар. Поможем с меню и списком закупки, приготовим напитки и обслужим гостей. Продолжительность работы согласуем заранее.',
    details: ['Меню и закупка', 'Ваше пространство', 'Время по договорённости'],
    message: 'Здравствуйте! Интересует услуга «Бармен на час».',
  },
  {
    id: 'spirits', number: '03', title: 'Крепкий бар',
    description: 'Отдельный формат с акцентом на крепкие напитки. Подберём состав меню и подачу под компанию; содержание программы обсудим вместе.',
    details: ['Крепкие напитки', 'Подбор меню', 'Работа бармена'],
    message: 'Здравствуйте! Хотим обсудить крепкий бар.',
  },
  {
    id: 'beer', number: '04', title: 'Пивной кейтеринг',
    description: 'Пивной бар для загородной встречи, корпоратива или вечеринки. Подберём ассортимент и объём под число гостей, организуем подачу и обслуживание.',
    details: ['Ассортимент', 'Подача', 'Обслуживание'],
    message: 'Здравствуйте! Хотим обсудить пивной кейтеринг.',
  },
];
const faqs = [
  { id: 'cost', question: 'Как рассчитывается стоимость?', answer: 'Учитываем меню, число гостей, время работы и площадку. После разговора подготовим предложение с составом услуг и стоимостью.' },
  { id: 'equipment', question: 'Что нужно подготовить на площадке?', answer: 'Обсудим место для бара и условия подключения. У нас своя стойка, оборудование и посуда — состав комплекта согласуем под ваше мероприятие. Если нужен только бармен, уточним, что уже есть на площадке.' },
  { id: 'glassware', question: 'Можно выбрать посуду и подачу?', answer: 'Да. Можно выбрать премиальное стекло или одноразовую посуду. Подберём вариант под напитки, оформление, условия площадки и бюджет.' },
  { id: 'menu', question: 'Меню можно составить под нас?', answer: 'Да. Расскажите о любимых напитках и пожеланиях гостей. Предложим варианты и согласуем состав меню до мероприятия.' },
];

function smsLink(message: string) {
  return 'sms:' + phone + '?body=' + encodeURIComponent(message);
}

const heroVideoSrc = '/grigoryev-malygin-bar/videos/hero-bar-v1.mp4?v=hands-v2';
const heroMotionSrc = '/grigoryev-malygin-bar/videos/hero-bar-motion-v1.webp';

function HeroFilm() {
  const video = useRef<HTMLVideoElement>(null);
  const requestPlayback = useRef<() => void>(() => {});
  const activateAnimation = useRef<() => void>(() => {});
  const animationError = useRef<() => void>(() => {});
  const animationMode = useRef(false);
  const [animation, setAnimation] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const node = video.current;
    if (!node) return;
    let inView = true;
    let disposed = false;
    let manuallyPaused = false;
    let attempt = 0;

    const startPlayback = (fromUser = false) => {
      if (fromUser) {
        manuallyPaused = false;
      }
      if (document.hidden || (!fromUser && (!inView || manuallyPaused))) return;

      // Set media properties before assigning the source, including on Safari.
      node.defaultMuted = true;
      node.muted = true;
      node.playsInline = true;
      node.autoplay = true;
      if (!node.getAttribute('src') || node.error) {
        node.src = heroVideoSrc;
        node.load();
      }
      const currentAttempt = ++attempt;
      setFailed(false);
      setLoading(true);
      // Keep play() in the click handler's call stack for gesture-only browsers.
      void node.play().catch((error: DOMException) => {
        if (disposed || currentAttempt !== attempt) return;
        setLoading(false);
        setPlaying(false);
        if (error.name === 'AbortError') return;
        activateAnimation.current();
      });
    };
    const syncPlayback = () => {
      if (document.hidden || !inView || manuallyPaused) {
        ++attempt;
        node.pause();
        setPlaying(false);
        setLoading(false);
      } else if (animationMode.current) {
        setPlaying(true);
        setLoading(false);
      } else if (node.paused && !node.error) {
        startPlayback();
      } else if (!node.paused && node.readyState >= 2) {
        setPlaying(true);
        setLoading(false);
      }
    };
    activateAnimation.current = () => {
      if (disposed || animationMode.current) return;
      animationMode.current = true;
      ++attempt;
      node.pause();
      setAnimation(true);
      setFailed(false);
      syncPlayback();
    };
    animationError.current = () => {
      animationMode.current = false;
      manuallyPaused = true;
      setAnimation(false);
      setPlaying(false);
      setLoading(false);
      setFailed(true);
    };
    requestPlayback.current = () => {
      if (animationMode.current) {
        manuallyPaused = !manuallyPaused;
        syncPlayback();
      } else if (node.paused) startPlayback(true);
      else {
        manuallyPaused = true;
        ++attempt;
        node.pause();
        setLoading(false);
      }
    };
    const observer = 'IntersectionObserver' in window ? new IntersectionObserver(([entry]) => {
      inView = entry.isIntersecting;
      syncPlayback();
    }, { threshold: 0.05 }) : null;
    observer?.observe(node);
    if (node.error) activateAnimation.current();
    else syncPlayback();
    document.addEventListener('visibilitychange', syncPlayback);
    window.addEventListener('pageshow', syncPlayback);
    return () => {
      disposed = true;
      requestPlayback.current = () => {};
      activateAnimation.current = () => {};
      animationError.current = () => {};
      animationMode.current = false;
      observer?.disconnect();
      document.removeEventListener('visibilitychange', syncPlayback);
      window.removeEventListener('pageshow', syncPlayback);
      node.pause();
      node.removeAttribute('src');
      node.load();
    };
  }, []);

  return <div className="hero-media">
    <div className="hero-film" aria-hidden="true">
      <video ref={video} src={heroVideoSrc} autoPlay muted playsInline loop preload="auto" tabIndex={-1}
        poster="/grigoryev-malygin-bar/images/hero-video-poster.jpg"
        onPlaying={() => { if (animationMode.current) video.current?.pause(); else { setPlaying(true); setLoading(false); setFailed(false); } }}
        onPause={() => { if (!animationMode.current) { setPlaying(false); setLoading(false); } }}
        onError={() => activateAnimation.current()}/>
      {animation && playing && <Image unoptimized className="film-animation" src={heroMotionSrc} alt="" width={480} height={854}
        onError={() => animationError.current()}/>}
    </div>
    <Button type="button" variant="ghost" className={playing || loading ? 'film-toggle' : 'film-start'}
      onClick={() => requestPlayback.current()}
      aria-label={playing ? 'Приостановить видео' : failed ? 'Повторить запуск видео' : 'Смотреть видео'}>
      {playing ? <Pause size={15} aria-hidden="true"/> : loading ? <Play size={15} aria-hidden="true"/> : <span className="film-play-icon"><Play size={26} aria-hidden="true"/></span>}
      <span>{playing ? 'Пауза' : loading ? 'Загрузка…' : failed ? 'Повторить' : 'Смотреть видео'}</span>
    </Button>
    {failed && <a className="film-open" href={heroVideoSrc} target="_blank" rel="noopener noreferrer">Открыть видео <ArrowUpRight size={16}/></a>}
  </div>;
}

export default function BarLanding() {
  const root = useRef<HTMLElement>(null);
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);

  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (media.matches || !('IntersectionObserver' in window)) return;
    const nodes = Array.from(root.current?.querySelectorAll<HTMLElement>('[data-reveal]') ?? []);
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          (entry.target as HTMLElement).dataset.visible = 'true';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    nodes.forEach(node => {
      if (node.getBoundingClientRect().top >= window.innerHeight) {
        node.dataset.visible = 'false';
        observer.observe(node);
      }
    });
    const showAll = () => {
      if (media.matches) {
        nodes.forEach(node => { node.dataset.visible = 'true'; });
        observer.disconnect();
      }
    };
    media.addEventListener('change', showAll);
    return () => { observer.disconnect(); media.removeEventListener('change', showAll); };
  }, []);

  async function copyPhone() {
    try {
      await navigator.clipboard.writeText('+7 919 656-45-24');
      setCopied(true);
      setCopyError(false);
    } catch { setCopyError(true); }
  }

  return <main ref={root} className="bar-site">
    <a className="skip-link" href="#presentation">К содержанию</a>

    <section className="hero" id="home" aria-labelledby="hero-title">
      <header className="header wrap">
        <a href="#home" className="monogram" aria-label="Григорьев и Малыгин — на главную">Г<span>/</span>М<span className="accent">.</span></a>
        <nav className="desktop-nav" aria-label="Основная навигация">
          <a href="#presentation">Коктейли</a><a href="#formats">Форматы</a><a href="#team">Команда</a>
        </nav>
        <a className="header-cta" href="#contact">Обсудить событие <ArrowUpRight size={18}/></a>
      </header>

      <div className="hero-layout wrap">
        <div className="hero-intro">
          <p className="eyebrow">ВЫЕЗДНОЙ БАР / ЧЕБОКСАРЫ</p>
          <h1 id="hero-title"><span className="hero-line">ГРИГОРЬЕВ</span><span className="hero-line"><span className="hero-amp">&</span> МАЛЫГИН<span className="accent">.</span></span></h1>
        </div>
        <div className="hero-bottom">
          <div>
            <p>Коктейли и барная команда<br/>для вашего события.</p>
            <a className="hero-action" href="#contact">Обсудить мероприятие <ArrowUpRight size={20}/></a>
          </div>
          <a className="round-link" href="#presentation" aria-label="Посмотреть коктейли"><ArrowDown size={24}/></a>
        </div>
        <HeroFilm/>
      </div>
    </section>

    <section className="presentation wrap section" id="presentation" aria-labelledby="presentation-title">
      <div className="section-top">
        <p className="eyebrow dark-label"><span className="section-number">01</span> МЕНЮ & ПОДАЧА</p>
      </div>
      <div className="gallery-heading" data-reveal>
        <h2 id="presentation-title">КОКТЕЙЛИ<br/>& <span className="outline-word">ПОДАЧА.</span></h2>
        <div className="gallery-intro">
          <p>Начинаем с ваших любимых напитков. Подбираем сочетания, бокалы и подачу под формат события.</p>
          <a className="text-link" href="#formats">Выбрать формат <ArrowUpRight size={18}/></a>
        </div>
      </div>
      <div className="cocktail-gallery">
        <figure className="cocktail-card" data-reveal>
          <Image unoptimized src="/grigoryev-malygin-bar/images/coupe-v1.jpg" alt="Светлый коктейль с пеной и цедрой в тонком бокале на ножке" width={1122} height={1402} loading="lazy"/>
        </figure>
        <figure className="cocktail-card" data-reveal>
          <Image unoptimized src="/grigoryev-malygin-bar/images/highball-v1.jpg" alt="Золотистый коктейль со льдом и грейпфрутом в высоком бокале" width={1122} height={1402} loading="lazy"/>
        </figure>
        <figure className="cocktail-card" data-reveal>
          <Image unoptimized src="/grigoryev-malygin-bar/images/rocks-v1.jpg" alt="Янтарный коктейль с крупным кубом льда и цедрой в низком бокале" width={1122} height={1402} loading="lazy"/>
        </figure>
      </div>
    </section>

    <section className="formats wrap section" id="formats" aria-labelledby="formats-title">
      <div className="section-top">
        <p className="eyebrow dark-label"><span className="section-number">02</span> ФОРМАТЫ</p>
      </div>
      <div className="formats-grid">
        <div className="formats-intro" data-reveal>
          <h2 id="formats-title">ВАШ<br/><span className="outline-word">ФОРМАТ.</span></h2>
          <p>Полный коктейльный бар или бармен для своей компании — начнём с того, что вам нужно.</p>
          <a className="text-link" href="#contact">Помочь с выбором <ArrowUpRight size={18}/></a>
        </div>
        <Accordion defaultValue={['cocktail']} className="service-accordion">
          {services.map(service => <AccordionItem key={service.id} value={service.id} className="service-item">
            <AccordionTrigger className="service-trigger"><span className="service-number">{service.number}</span><span className="service-name">{service.title}</span></AccordionTrigger>
            <AccordionContent className="service-content">
              <p>{service.description}</p>
              <ul className="service-details">{service.details.map(detail => <li key={detail}>{detail}</li>)}</ul>
              <a className="text-link" href={smsLink(service.message)}>Обсудить этот формат <ArrowUpRight size={18}/></a>
            </AccordionContent>
          </AccordionItem>)}
        </Accordion>
      </div>
    </section>

    <section className="team dark" id="team" aria-labelledby="team-title">
      <div className="wrap section">
        <div className="section-top">
          <p className="eyebrow"><span className="section-number">03</span> КОМАНДА</p>
        </div>
        <div className="team-heading" data-reveal>
          <h2 id="team-title">ЗА БАРОМ<span className="accent">.</span></h2>
          <p>Алексей и Роман — партнёры проекта.<br/>У каждого больше десяти лет в барной индустрии.</p>
        </div>
        <div className="founders-grid">
          <article className="founder" data-reveal>
            <div className="founder-photo alex paired-portrait">
              <Image unoptimized src="/grigoryev-malygin-bar/images/team-portraits-alex-tone-v4.jpg" alt="Алексей Григорьев — партнёр проекта" width={1584} height={993} loading="lazy"/>
              <span className="photo-label">ПАРТНЁР</span>
            </div>
            <div className="founder-title"><h3>Алексей Григорьев</h3><span><strong>10+</strong>лет в индустрии</span></div>
            <p>Барная и ресторанная индустрия. Опыт работы старшим барменом и бренд-шефом.</p>
          </article>
          <article className="founder" data-reveal>
            <div className="founder-photo roman paired-portrait">
              <Image unoptimized src="/grigoryev-malygin-bar/images/team-portraits-diptych-v3.jpg" alt="Роман Малыгин — партнёр проекта" width={1586} height={992} loading="lazy"/>
              <span className="photo-label">ПАРТНЁР</span>
            </div>
            <div className="founder-title"><h3>Роман Малыгин</h3><span><strong>10+</strong>лет в индустрии</span></div>
            <p>Барная индустрия и выездное обслуживание. Опыт организации работы бара на мероприятиях.</p>
          </article>
        </div>
      </div>
    </section>

    <section className="how wrap section" id="how" aria-labelledby="how-title">
      <div className="section-top"><p className="eyebrow dark-label"><span className="section-number">04</span> КАК ЗАКАЗАТЬ</p></div>
      <div className="how-grid">
        <div data-reveal><h2 id="how-title">ОБСУДИМ<br/>ДЕТАЛИ<span className="accent">.</span></h2><p className="how-intro">Можно прийти с готовым заданием или пока только с датой и идеей.</p></div>
        <div className="how-content">
          <ol className="steps">
            <li><span>01</span><div><h3>Расскажите о событии</h3><p>Дата, площадка, число гостей. Любимые напитки и пожелания к бару.</p></div></li>
            <li><span>02</span><div><h3>Выберем меню и подачу</h3><p>Согласуем формат, время работы и стоимость. Соберём предложение под ваше мероприятие.</p></div></li>
            <li><span>03</span><div><h3>Увидимся на площадке</h3><p>Подготовим бар к согласованному времени и возьмём обслуживание гостей на себя.</p></div></li>
          </ol>
          <Accordion className="faq">
            {faqs.map(faq => <AccordionItem key={faq.id} value={faq.id}>
              <AccordionTrigger className="faq-trigger">{faq.question}</AccordionTrigger>
              <AccordionContent className="faq-content">{faq.answer}</AccordionContent>
            </AccordionItem>)}
          </Accordion>
        </div>
      </div>
    </section>

    <footer className="contact" id="contact">
      <div className="wrap section">
        <p className="eyebrow">ЕСТЬ ДАТА? ДАВАЙТЕ ЗНАКОМИТЬСЯ.</p>
        <div className="contact-grid">
          <h2>ВАШЕ<br/>СОБЫТИЕ<span className="contact-period">.</span><br/>НАШ БАР<span className="contact-period">.</span></h2>
          <div className="contact-info">
            <p>Расскажите, что планируете.<br/>Обсудим бар и подготовим предложение.</p>
            <a className="phone-link" href={'tel:' + phone}>+7 919 656-45-24 <ArrowUpRight size={28}/></a>
            <div className="contact-actions">
              <a className="contact-button" href={'tel:' + phone}><Phone size={17}/> Позвонить</a>
              <a className="contact-button secondary-button" href={smsLink('Здравствуйте! Хотим обсудить бар для мероприятия. Дата: . Гостей: . Площадка: .')}><MessageCircle size={17}/> Написать SMS</a>
            </div>
            <Button className="copy-phone" variant="ghost" onClick={copyPhone}>{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? 'Номер скопирован' : 'Скопировать номер'}</Button>
            <output className="copy-status" aria-live="polite">{copyError ? 'Не удалось скопировать. Номер можно выделить выше.' : copied ? 'Номер телефона скопирован.' : ''}</output>
          </div>
        </div>
        <div className="footer-bottom">
          <a href="#home" className="brand">ГРИГОРЬЕВ<span>& МАЛЫГИН.</span></a>
          <p>Выездной бар<br/>Чебоксары</p>
          <a href="#home">Наверх <ArrowUpRight size={17}/></a>
          <span>© 2026</span>
        </div>
      </div>
    </footer>
  </main>;
}
