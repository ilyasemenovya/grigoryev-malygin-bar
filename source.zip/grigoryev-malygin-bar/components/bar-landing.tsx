'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ArrowDown, ArrowUpRight, Copy, Check, Phone, MessageCircle } from 'lucide-react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';

const phone = '+79196564524';
const services = [
 {id:'cocktail',number:'01',title:'Выездной бар',label:'Коктейльный бар с полным оснащением',description:'Согласуем коктейльное меню и подачу. Привезём свою стойку, оборудование и посуду, подготовим бар на площадке и возьмём обслуживание гостей на себя.',details:['Своя барная стойка','Своя посуда и оборудование','Работа барменов'],message:'Здравствуйте! Хотим обсудить выездной коктейльный бар.'},
 {id:'bartender',number:'02',title:'Бармен на час',label:'Бармен для вашей площадки',description:'Для домашней вечеринки или площадки, где уже есть бар. Поможем составить меню и список закупки, приготовим напитки и обслужим гостей. Часы работы и необходимый инвентарь согласуем заранее.',details:['Частные встречи','Меню и список закупки','Время по договорённости'],message:'Здравствуйте! Интересует услуга «Бармен на час».'},
 {id:'spirits',number:'03',title:'Крепкий бар',label:'Бар с акцентом на крепкие напитки',description:'Подберём крепкие напитки и формат подачи под вашу компанию. Обсудим состав меню, посуду и работу бармена. Привезём всё необходимое для согласованной программы.',details:['Крепкие напитки','Подбор посуды','Работа бармена'],message:'Здравствуйте! Хотим обсудить крепкий бар.'},
 {id:'beer',number:'04',title:'Пивной кейтеринг',label:'Пивной бар на вашей площадке',description:'Согласуем ассортимент и объём пива под число гостей и время работы. Привезём оборудование и посуду, организуем подачу и обслуживание.',details:['Подбор ассортимента','Оборудование для подачи','Обслуживание гостей'],message:'Здравствуйте! Хотим обсудить пивной кейтеринг.'}
];

function smsLink(message:string) { return 'sms:' + phone + '?body=' + encodeURIComponent(message); }

export default function Home() {
 const [copied,setCopied] = useState(false);
 const [copyError,setCopyError] = useState(false);
 async function copyPhone() {
  try { await navigator.clipboard.writeText('+7 919 656-45-24'); setCopied(true); setCopyError(false); }
  catch { setCopyError(true); }
 }
 return <main>
  <a className="skip-link" href="#formats">К содержанию</a>
  <section className="hero" id="home">
   <div className="hero-photo"><Image unoptimized src="/grigoryev-malygin-bar/images/cocktail-hero.webp" alt="Два коктейля в тонких бокалах на барной стойке" width={1536} height={1024} fetchPriority="high"/></div>
   <header className="header wrap">
    <a href="#home" className="brand" aria-label="Григорьев и Малыгин — на главную">ГРИГОРЬЕВ<span>& МАЛЫГИН<span className="accent">.</span></span></a>
    <nav className="desktop-nav" aria-label="Основная навигация"><a href="#formats">Форматы</a><a href="#team">Команда</a><a href="#how">Как заказать</a></nav>
    <a className="header-cta" href="#contact">Обсудить событие <ArrowUpRight size={17}/></a>
   </header>
   <div className="hero-content wrap">
    <p className="eyebrow"><span className="live-dot"/>ВЫЕЗДНОЙ БАР · ЧЕБОКСАРЫ</p>
    <h1>БАР.<br/>С ВЫЕЗДОМ<br/>К ВАМ<span className="accent">.</span></h1>
    <div className="hero-bottom">
     <div><p>Своя стойка, оборудование и посуда.<br/>Меню и подача — под ваше событие.</p><a className="hero-action" href="#contact">Обсудить ваш бар <ArrowUpRight size={18}/></a></div>
     <a className="round-link" href="#formats"><span>ВЫБРАТЬ<br/>СВОЙ ФОРМАТ</span><ArrowDown size={23}/></a>
    </div>
   </div>
   <span className="hero-index">КОКТЕЙЛИ / КОМАНДА / ОБОРУДОВАНИЕ</span>
  </section>

  <div className="occasion-strip" aria-label="Для свадеб, корпоративов и частных вечеринок"><span>СВАДЬБЫ</span><span aria-hidden="true">✳</span><span>КОРПОРАТИВЫ</span><span aria-hidden="true">✳</span><span>ЧАСТНЫЕ ВЕЧЕРИНКИ</span><span aria-hidden="true">✳</span><span>ЗАГОРОДНЫЕ МЕРОПРИЯТИЯ</span></div>

  <section className="intro wrap section" aria-labelledby="intro-title">
   <p className="eyebrow dark-label"><span className="section-number">01</span> НАШ ПОДХОД</p>
   <div className="intro-grid"><h2 id="intro-title">СТОЙКА.<br/>ПОСУДА.<br/><span className="outline-word">ВСЁ СВОЁ.</span></h2>
    <div className="intro-copy"><p className="lead-copy">Своя барная стойка, своё оборудование и своя посуда. Собираем бар под площадку, число гостей и меню.</p><p>Премиальное стекло или одноразовая посуда — выбираете вы. Подскажем, что подойдёт под напитки, формат события и бюджет.</p><p>Заранее согласуем, что привозим, как подаём и сколько это стоит. Подготовка бара и обслуживание — на нашей команде.</p><a className="text-link" href="#team">Познакомиться с командой <ArrowUpRight size={18}/></a></div>
   </div>
  </section>

  <section className="formats wrap section" id="formats" aria-labelledby="formats-title">
   <div className="section-top"><p className="eyebrow dark-label"><span className="section-number">02</span> ФОРМАТЫ</p><span className="section-aside">Четыре формата выездного бара.</span></div>
   <div className="formats-grid">
    <div className="formats-intro"><h2 id="formats-title">КАКОЙ БАР<br/>ВАМ НУЖЕН<span className="accent">?</span></h2><figure className="detail-photo"><Image unoptimized src="/grigoryev-malygin-bar/images/cocktail-detail.webp" alt="Янтарный коктейль с крупным льдом и апельсиновой цедрой" width={1122} height={1402} loading="lazy"/><figcaption>МЕНЮ И ПОДАЧА — ПОД ВАШ ФОРМАТ <span>↗</span></figcaption></figure></div>
    <Accordion defaultValue={['cocktail']} className="service-accordion">
     {services.map(s=><AccordionItem key={s.id} value={s.id} className="service-item">
      <AccordionTrigger className="service-trigger"><span className="service-number">{s.number}</span><span className="service-name">{s.title}</span></AccordionTrigger>
      <AccordionContent className="service-content"><p className="service-label">{s.label}</p><p>{s.description}</p><ul className="service-details">{s.details.map(d=><li key={d}>{d}</li>)}</ul><a className="text-link" href={smsLink(s.message)}>Обсудить этот формат <ArrowUpRight size={18}/></a></AccordionContent>
     </AccordionItem>)}
    </Accordion>
   </div>
  </section>

  <section className="team dark" id="team" aria-labelledby="team-title"><div className="wrap section">
   <div className="section-top"><p className="eyebrow"><span className="section-number">03</span> КОМАНДА</p><span className="section-aside">Алексей Григорьев и Роман Малыгин.</span></div>
   <div className="team-heading"><h2 id="team-title">КТО СТОИТ<br/>ЗА БАРОМ<span className="accent">.</span></h2><p>За проектом — опыт работы в барах, ресторанах и на выездных мероприятиях. Он помогает точно оценить задачу: от меню до организации работы на площадке.</p></div>
   <div className="founders-grid">
    <article className="founder"><div className="founder-photo alex"><Image unoptimized src="/grigoryev-malygin-bar/images/aleksey-grigoryev.jpg" alt="Алексей Григорьев" width={853} height={1280} loading="lazy"/><span className="photo-label">АЛЕКСЕЙ / СООСНОВАТЕЛЬ</span></div><div className="founder-title"><h3>Алексей Григорьев</h3><span>10+ лет<br/>в индустрии</span></div><p>Более десяти лет в барной и ресторанной индустрии. Опыт работы старшим барменом и бренд-шефом.</p></article>
    <article className="founder"><div className="founder-photo roman"><Image unoptimized src="/grigoryev-malygin-bar/images/roman-malygin.jpg" alt="Роман Малыгин с бокалом у винных стеллажей" width={640} height={640} loading="lazy"/><span className="photo-label">РОМАН / СООСНОВАТЕЛЬ</span></div><div className="founder-title"><h3>Роман Малыгин</h3><ArrowUpRight aria-hidden="true" size={28}/></div><p>Опыт работы в барной индустрии и организации выездного обслуживания: подготовка бара, оборудование и работа с гостями.</p></article>
   </div>
   <div className="team-bottom"><span>ДО ВЫЕЗДА СОГЛАСУЕМ</span><p>Меню, посуду, оборудование.<br/>Команду, время работы и стоимость.</p></div>
  </div></section>

  <section className="how wrap section" id="how" aria-labelledby="how-title">
   <div className="section-top"><p className="eyebrow dark-label"><span className="section-number">04</span> ОРГАНИЗАЦИЯ</p></div>
   <div className="how-grid"><div><h2 id="how-title">ОТ ЗАЯВКИ<br/>ДО ПЛОЩАДКИ<span className="accent">.</span></h2><p className="how-intro">Для расчёта нужны дата, площадка и число гостей. Дальше обсудим меню, подачу и время работы.</p></div><ol className="steps"><li><span>01</span><div><h3>Расскажите о мероприятии</h3><p>Пришлите дату, место и число гостей. Расскажите, какие напитки хотите и на какой бюджет рассчитываете.</p></div></li><li><span>02</span><div><h3>Согласуем детали</h3><p>Подберём меню, стойку и посуду. В расчёте укажем состав услуг, команду и часы работы.</p></div></li><li><span>03</span><div><h3>Встретимся на площадке</h3><p>Подготовим бар к согласованному времени и возьмём обслуживание гостей на себя.</p></div></li></ol></div>
   <Accordion className="faq"><AccordionItem value="cost"><AccordionTrigger className="faq-trigger">Сколько стоит выездной бар?</AccordionTrigger><AccordionContent className="faq-content">Стоимость зависит от меню, числа гостей, продолжительности и места проведения. После обсуждения подготовим расчёт с понятным составом услуг.</AccordionContent></AccordionItem><AccordionItem value="equipment"><AccordionTrigger className="faq-trigger">Стойка, оборудование и посуда у вас свои?</AccordionTrigger><AccordionContent className="faq-content">Да. У нас своя барная стойка, оборудование и посуда. Комплект подбираем под меню и площадку и указываем в предложении. Для услуги «Бармен на час» обсудим, что уже есть у вас и что нужно привезти.</AccordionContent></AccordionItem><AccordionItem value="menu"><AccordionTrigger className="faq-trigger">Можно подобрать меню под нашу компанию?</AccordionTrigger><AccordionContent className="faq-content">Да. Расскажите о любимых напитках, пожеланиях гостей и теме мероприятия. Учтём это при составлении меню; состав каждой позиции согласуем с вами.</AccordionContent></AccordionItem></Accordion>
  </section>

  <footer className="contact" id="contact"><div className="wrap section">
   <p className="eyebrow"><span className="live-dot"/> ОБСУДИМ ВАШЕ МЕРОПРИЯТИЕ</p>
   <div className="contact-grid"><h2>ГДЕ СТАВИМ<br/>БАР<span className="contact-period">?</span></h2><div className="contact-info"><p>Пришлите дату, площадку и число гостей.<br/>Предложим меню и рассчитаем стоимость.</p><a className="phone-link" href={'tel:'+phone}>+7 919 656-45-24 <ArrowUpRight size={28}/></a><div className="contact-actions"><a className="contact-button" href={'tel:'+phone}><Phone size={17}/> Позвонить</a><a className="contact-button secondary-button" href={smsLink('Здравствуйте! Хотим обсудить бар для мероприятия. Дата: . Гостей: . Площадка: .')}><MessageCircle size={17}/> Написать SMS</a></div><Button className="copy-phone" variant="ghost" onClick={copyPhone}>{copied?<Check size={16}/>:<Copy size={16}/>} {copied?'Номер скопирован':'Скопировать номер'}</Button><output className="copy-status" aria-live="polite">{copyError?'Не удалось скопировать. Номер можно выделить выше.':copied?'Номер телефона скопирован.':''}</output></div></div>
   <div className="footer-bottom"><a href="#home" className="brand">ГРИГОРЬЕВ<span>& МАЛЫГИН.</span></a><p>Выездной бар<br/>Чебоксары</p><a href="#home">Наверх <ArrowUpRight size={17}/></a><span>© 2026</span></div>
  </div></footer>
 </main>;
}
