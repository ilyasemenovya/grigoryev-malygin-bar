import type { Metadata } from 'next';
import localFont from 'next/font/local';
import './globals.css';
export const dynamic = 'force-static';
const bodyFont = localFont({ src: '../public/fonts/Onest.ttf', variable: '--font-body', weight: '400 800', style: 'normal', display: 'swap' });
const logoFont = localFont({ src: '../public/fonts/RAYDIS.woff2', variable: '--font-logo', weight: '700', style: 'normal', display: 'swap' });
const scriptFont = localFont({ src: '../public/fonts/CormorantGaramond-Italic.ttf', variable: '--font-script', weight: '400', style: 'italic', display: 'swap' });
export const metadata: Metadata = { title: 'GM.EVENT — бар для вашего события', description: 'Четыре варианта коктейльного бара, инфьюз-бар, безалкогольный бар, мастер-классы, коктейльное казино и бармен на час. GM.EVENT, Чебоксары.', metadataBase: new URL('https://ilyasemenovya.github.io/grigoryev-malygin-bar/'), icons: { icon: '/grigoryev-malygin-bar/favicon.svg' }, robots: {index:false,follow:false}};
export default function RootLayout({children}: Readonly<{children:React.ReactNode}>) {return <html lang="ru"><body className={bodyFont.variable+' '+logoFont.variable+' '+scriptFont.variable}>{children}</body></html>}
