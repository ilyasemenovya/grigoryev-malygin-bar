import type { Metadata } from 'next';
import { Manrope, Oswald } from 'next/font/google';
import './globals.css';
export const dynamic = 'force-static';
const bodyFont = Manrope({ variable: '--font-body', subsets: ['latin','cyrillic'], display: 'swap' });
const displayFont = Oswald({ variable: '--font-display', subsets: ['latin','cyrillic'], display: 'swap' });
export const metadata: Metadata = { title: 'Григорьев & Малыгин — выездной бар в Чебоксарах', description: 'Выездной бар Алексея Григорьева и Романа Малыгина. Коктейльный бар, бармен на час, самогонное шоу и пивной бар для ваших событий.', metadataBase: new URL('https://ilyasemenovya.github.io/grigoryev-malygin-bar/'), icons: { icon: '/grigoryev-malygin-bar/favicon.svg' }, robots: {index:false,follow:false}};
export default function RootLayout({children}: Readonly<{children:React.ReactNode}>) {return <html lang="ru"><body className={bodyFont.variable+' '+displayFont.variable}>{children}</body></html>}