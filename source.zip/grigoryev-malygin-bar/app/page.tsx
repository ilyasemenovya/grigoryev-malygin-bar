import BarLanding from '@/components/bar-landing';
export const dynamic = 'force-static';
export const revalidate = false;
export default function Home() { return <BarLanding />; }
