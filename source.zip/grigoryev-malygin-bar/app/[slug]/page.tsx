import { notFound, redirect } from 'next/navigation';
import { ProductPage } from '@/components/product-page';
import { services, legacyServiceSlugs } from '@/lib/services';

export const dynamic = 'force-static';
export const dynamicParams = false;
export function generateStaticParams() { return [...services.map(service => ({slug: service.slug})), ...legacyServiceSlugs.map(slug => ({slug}))]; }
export default async function ServicePage({params}: {params: Promise<{slug: string}>}) {
  const {slug} = await params;
  if (legacyServiceSlugs.includes(slug)) redirect('/#formats');
  const service = services.find(item => item.slug === slug);
  if (!service) notFound();
  return <ProductPage service={service}/>;
}
