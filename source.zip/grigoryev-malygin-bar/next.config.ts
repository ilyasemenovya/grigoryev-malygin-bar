import type { NextConfig } from 'next';
const nextConfig: NextConfig = {
  output: 'export',
  basePath: '/grigoryev-malygin-bar',
  trailingSlash: true,
  images: { unoptimized: true },
};
export default nextConfig;
