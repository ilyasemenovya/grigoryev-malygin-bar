import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);
const esbuild=createRequire(import.meta.resolve('vinext'))('esbuild');
const root=resolve(import.meta.dirname,'..'),out=resolve(root,'demo');
mkdirSync(out,{recursive:true});
const inlineImages={name:'inline-demo-images',setup(build){
build.onLoad({filter:/bar-landing\.tsx$/},({path})=>{
let source=readFileSync(path,'utf8').replace("import Image from 'next/image';",'').replaceAll('<Image unoptimized','<img');
source=source.replace(/src="\/grigoryev-malygin-bar\/images\/([^"]+)"/g,(_,name)=>'src="data:'+(name.endsWith('.webp')?'image/webp':'image/jpeg')+';base64,'+readFileSync(resolve(root,'public/images',name)).toString('base64')+'"');
return {contents:source,loader:'tsx',resolveDir:resolve(root,'components')};
});}};
const options={absWorkingDir:root,bundle:true,jsx:'automatic',minify:true,define:{'process.env.NODE_ENV':'"production"'},plugins:[inlineImages],logLevel:'warning'};
const client=await esbuild.build({...options,entryPoints:['demo-src/client.tsx'],platform:'browser',format:'iife',write:false});
await esbuild.build({...options,entryPoints:['demo-src/render.tsx'],platform:'node',format:'esm',outfile:resolve(out,'render.mjs'),packages:'external'});
const {render}=await import(pathToFileURL(resolve(out,'render.mjs')).href);
const css=readFileSync(resolve(root,'demo-src/site.css'),'utf8'),icon=readFileSync(resolve(root,'public/favicon.svg')).toString('base64');
const js=client.outputFiles[0].text.replaceAll('</script','<\\/script');
const html='<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Григорьев & Малыгин — выездной бар</title><link rel="icon" href="data:image/svg+xml;base64,'+icon+'"><style>'+css+'</style></head><body style="--font-body:Manrope;--font-display:Oswald"><div id="root">'+render()+'</div><script>'+js+'</script></body></html>';
writeFileSync(resolve(out,'index.html'),html);writeFileSync(resolve(out,'.nojekyll'),'');
console.log('Standalone demo built:',(Buffer.byteLength(html)/1024/1024).toFixed(2),'MB');
