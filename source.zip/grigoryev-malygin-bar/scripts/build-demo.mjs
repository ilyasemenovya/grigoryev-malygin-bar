import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import tailwindcss from '@tailwindcss/postcss';
const postcss=createRequire(import.meta.resolve('@tailwindcss/postcss'))('postcss');
const esbuild=createRequire(import.meta.resolve('vinext'))('esbuild');
const root=resolve(import.meta.dirname,'..'),out=resolve(root,'demo');
mkdirSync(out,{recursive:true});
const files=new Set(['index.html']);
function publishAsset(name,bytes){
writeFileSync(resolve(out,name),bytes);files.add(name);return './'+name;
}
function imageAsset(name){
const bytes=readFileSync(resolve(root,'public/images',name));
const dot=name.lastIndexOf('.');
const target='asset-'+name.slice(0,dot)+'-'+createHash('sha256').update(bytes).digest('hex').slice(0,10)+name.slice(dot);
return publishAsset(target,bytes);
}
const localAssets={name:'local-demo-assets',setup(build){
build.onLoad({filter:/bar-landing\.tsx$/},({path})=>{
let source=readFileSync(path,'utf8').replace("import Image from 'next/image';",'').replaceAll('<Image unoptimized','<img');
source=source.replace(/'\/grigoryev-malygin-bar\/videos\/([^']+)'/g,(_,name)=>{
copyFileSync(resolve(root,'public/videos',name),resolve(out,name));files.add(name);return "'./"+name+"'";
});
source=source.replace(/(src|poster)="\/grigoryev-malygin-bar\/images\/([^"]+)"/g,(_,attribute,name)=>attribute+'="'+imageAsset(name)+'"');
return {contents:source,loader:'tsx',resolveDir:resolve(root,'components')};
});}};
const options={absWorkingDir:root,bundle:true,jsx:'automatic',minify:true,define:{'process.env.NODE_ENV':'"production"'},plugins:[localAssets],logLevel:'warning'};
const client=await esbuild.build({...options,entryPoints:['demo-src/client.tsx'],platform:'browser',format:'iife',write:false});
await esbuild.build({...options,entryPoints:['demo-src/render.tsx'],platform:'node',format:'esm',outfile:resolve(out,'render.mjs'),packages:'external'});
const {render}=await import(pathToFileURL(resolve(out,'render.mjs')).href);
const stylesheet=resolve(root,'app/globals.css');
const compiled=await postcss([tailwindcss()]).process(readFileSync(stylesheet,'utf8'),{from:stylesheet,map:false});
const css=compiled.css+'\n'+readFileSync(resolve(root,'demo-src/fonts.css'),'utf8');
const icon=readFileSync(resolve(root,'public/favicon.svg')).toString('base64');
const js=client.outputFiles[0].text;
const scriptSrc=publishAsset('bar-app-'+createHash('sha256').update(js).digest('hex').slice(0,12)+'.js',js);
const html='<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Григорьев & Малыгин — выездной бар</title><link rel="icon" href="data:image/svg+xml;base64,'+icon+'"><style>'+css+'</style></head><body style="--font-body:Manrope;--font-display:Oswald"><div id="root">'+render()+'</div><script defer src="'+scriptSrc+'"></script></body></html>';
writeFileSync(resolve(out,'index.html'),html);writeFileSync(resolve(out,'.nojekyll'),'');
writeFileSync(resolve(out,'asset-manifest.json'),JSON.stringify({files:[...files].sort()},null,2)+'\n');
console.log('Site built:',(Buffer.byteLength(html)/1024).toFixed(1),'KB HTML;',files.size,'deployment files');
