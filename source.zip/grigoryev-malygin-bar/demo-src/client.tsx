import {hydrateRoot} from 'react-dom/client';
import BarLanding from '@/components/bar-landing';
hydrateRoot(document.getElementById('root')!, <BarLanding/>);
