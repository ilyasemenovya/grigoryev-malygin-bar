import {hydrateRoot} from 'react-dom/client';
import BarLanding from '@/components/bar-landing';
import { ProductPage } from '@/components/product-page';
import { services } from '@/lib/services';
const root = document.getElementById('root')!;
const service = services.find(item => item.slug === root.dataset.page);
hydrateRoot(root, service ? <ProductPage service={service}/> : <BarLanding/>);
