import {renderToString} from 'react-dom/server';
import BarLanding from '@/components/bar-landing';
import { ProductPage } from '@/components/product-page';
import { services, legacyServiceSlugs } from '@/lib/services';
export const pages = [{slug: '', title: 'GM.EVENT — бар для вашего события', description: 'Экспресс, Базовый, Комфорт, Премиум, инфьюз-бар, безалкогольный бар, мастер-классы, коктейльное казино и бармен на час. GM.EVENT, Чебоксары.'}, ...services.map(service => ({slug: service.slug, title: `${service.title} — GM.EVENT`, description: service.description}))];
export const redirects = legacyServiceSlugs;
export function render(slug = '') {
  const service = services.find(item => item.slug === slug);
  return renderToString(service ? <ProductPage service={service}/> : <BarLanding/>);
}
