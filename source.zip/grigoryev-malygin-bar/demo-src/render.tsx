import {renderToString} from 'react-dom/server';
import BarLanding from '@/components/bar-landing';
export function render(){return renderToString(<BarLanding/>);}
